import sqlite3
from datetime import datetime
from pydrive.auth import GoogleAuth
from pydrive.drive import GoogleDrive

# Google Drive kimlik doğrulaması
gauth = GoogleAuth()
gauth.LocalWebserverAuth()  # Kimlik doğrulamasını gerçekleştirir

# Google Drive bağlantısı oluştur
drive = GoogleDrive(gauth)

# SQLite veritabanı dosyası
db_file = 'db.sqlite'

# Veritabanını yedekleme fonksiyonu
def backup_database():
    now = datetime.now()
    backup_file_name = f'backup_{now.strftime("%Y%m%d%H%M%S")}.sqlite'
    
    # Veritabanına bağlan
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()
    
    # Veritabanını yedekle
    with open(backup_file_name, 'w') as backup:
        for line in conn.iterdump():
            backup.write(f'{line}\n')
    
    # Veritabanı bağlantısını kapat
    conn.close()
    
    return backup_file_name

# Yedek dosyasını Google Drive'a yükleme fonksiyonu
def upload_to_google_drive(file_name):
    file = drive.CreateFile({'title': file_name})
    file.SetContentFile(file_name)
    file.Upload()

# Ana iş akışı
if __name__ == "__main__":
    backup_file = backup_database()
    upload_to_google_drive(backup_file)
