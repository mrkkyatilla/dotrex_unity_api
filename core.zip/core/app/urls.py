from django.urls import path
from . import views
from django.contrib.auth.views import LoginView


urlpatterns = [
    path('', views.index, name='get_data'),
    
    path('login/', views.login_view, name='login'),  
    path('logout/', views.logout_view, name='logout'), 
    
    path('save/<str:mode>=<int:unity_player_id>/', views.save_data, name='save_data'),
    path('get/', views.download_json, name='download_json'),
    
    
    path('get/version/', views.get_version_data, name='get_data_ver'),
    path('get/info/', views.get_info_data, name='get_data_info'),
    
    
    path('get/<int:player_unity_id>/', views.player_detail_get, name='player_detail_get'),
    
    ]   