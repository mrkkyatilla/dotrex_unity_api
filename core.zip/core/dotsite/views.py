from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from django.views.decorators.csrf import csrf_exempt
 
from app.models import MyData,FeedBacks,Bugs,Players


def index(request):
    return render(request,"index.html")

def view_data(request):
    
    feed_backs = FeedBacks.objects.all().values()
    bugs = Bugs.objects.all().values()
    players = Players.objects.all().values()
    context = {'feedbacks': list(feed_backs), 'bugs': list(bugs), 'players': list(players)}
    return render(request,"list_data.html",context)


def login(request):
    return render(request,"login.html")

