from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='get_data'),
    path('list/', views.view_data, name='get_data'),
 
    ]

